use SSISDB

select *
from catalog.folders

exec catalog.rename_folder @old_name = 'Deployment-New',
@new_name = DeploymentUpdated

select *
from catalog.packages

select *
from catalog.object_versions