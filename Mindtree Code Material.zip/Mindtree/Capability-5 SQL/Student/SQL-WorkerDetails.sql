CREATE TABLE Worker
(
	Worker_Id int not null Primary key identity(001,1),
	first_name char(25),
	last_name char(25),
	salary int,
	joining_date datetime,
	department char(25)
)


insert into Worker
(first_name,last_name,salary,joining_date,department)
values
('Monika','Arora',100000,'14-02-2020 09.00.00','HR'),
('Niharika','Verma',80000,'14-06-2011 09.00.00','Admin'),
('Vishal','Singhal',300000,'14-02-2020 09.00.00','HR'),
('Amitabh','Singh',500000,'14-02-2020 09.00.00','Admin'),
('Vivek','Bhati',500000,'14-06-2011 09.00.00','Admin'),
('Vipul','Diwan',200000,'14-06-2011 09.00.00','Account'),
('Satish','Kumar',75000,'14-01-2020 09.00.00','Account'),
('Geetika','Chauhan',90000,'14-04-2011 09.00.00','Admin');