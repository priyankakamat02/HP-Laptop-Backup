--Name the teachers who are teaching more than one subject
select teachers.name
from teachers, grades g
where teachers.tid= g.teacherid
group by teachers.name
having count(*)>1

--Display the student name, teacher name, subject name and grade of students who secured grade "B"
select s.name as 'student_name',t.name as 'teacher_name',sub.name as 'subject_name',g.grade as 'grade'
from students s,teachers t, subjects sub, grades g
where s.id =g.studentid and t.tid= g.teacherid and sub.subid= g.subjectid

--Display the subject details for which the exam is not conducted
select *
from students s left join grades g
on s.id = g.studentid
where g.studentid is null

--Display the 2 students name and their teacher name who appeared for one subject in the exam.
select s.name as 'student_name',t.name as 'teacher_name'
from students s, teachers t, subjects sub, grades g
where s.id = g.studentid and t.tid= g.teacherid and sub.subid= g.subjectid
group by s.name ,t.name
having COUNT(*) =1

--display teacher name and student name having maximum marks where subject is mathematics
select t.name as 'teacher_name',s.name as 'student_name'
from students s, teachers t, subjects sub, grades g
where s.id = g.studentid and t.tid= g.teacherid
and sub.name = 'Mathematics'
and g.marks = (select max(marks) from grades)