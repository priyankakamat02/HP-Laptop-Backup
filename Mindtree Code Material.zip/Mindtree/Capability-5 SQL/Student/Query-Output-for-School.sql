select *
from [dbo].[students];

select *
from [dbo].[subjects]

select *
from [dbo].[teachers]

select *
from [dbo].[grades]

--select teachers.name
--from teachers, grades g
--where teachers.tid = g.teacherid
--group by teachers.name
--having COUNT(*) >1;

--select s.name, t.name,sub.name, g.grade
--from students s,teachers t,subjects sub, grades g
--where s.id =g.studentid and t.tid = g.teacherid and sub.subid = g.subjectid and g.grade = 'B'

--select t.name, s.name
--from teachers t, students s, grades g, subjects sub
--where t.tid = g.teacherid and s.id= g.studentid and sub.name = 'Mathematics'
--and g.marks = (select MAX(marks) from grades)

--select *
--from students s left join grades g
--on s.id = g.studentid
--where g.studentid is null
select s.name, t.name
from students s, teachers t,grades g, subjects sub
where s.id =g.studentid and t.tid =g.teacherid and sub.subid = g.subjectid
group by s.name, t.name
having count(*) = 1

select TOP(2) s.name, t.name
from students s, teachers t,grades g, subjects sub
where s.id =g.studentid and t.tid =g.teacherid and sub.subid = g.subjectid
group by s.name, t.name
having count(*) = 1