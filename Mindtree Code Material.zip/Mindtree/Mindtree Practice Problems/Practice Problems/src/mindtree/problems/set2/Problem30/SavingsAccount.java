package mindtree.problems.set2.Problem30;

public class SavingsAccount {

	private double balance;
	private int interestRate;
	private int accountNo;
	
	public SavingsAccount(double balance, int interestRate, int accountNo) {
		super();
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountNo = accountNo;
	}

	public SavingsAccount() {
		
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(int interestRate) {
		this.interestRate = interestRate;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	public void withDraw(double amount) throws InsufficientBalanceException {
		if(amount > balance)
		{
			throw new InsufficientBalanceException("Balance insufficient");
		}
		else
		{
			balance=balance-amount;
			System.out.print("Successfully withdrawn "+amount+" rupees\n");
			System.out.print("Available Balance: "+balance);
		}

	}
	
	public void calculateInterest() {
		

	}

}
