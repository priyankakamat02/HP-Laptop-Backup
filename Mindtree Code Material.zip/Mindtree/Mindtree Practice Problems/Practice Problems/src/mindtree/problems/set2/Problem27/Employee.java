package mindtree.problems.set2.Problem27;

public class Employee {

	private int empId;
	private String empName;
	private String empDesign;
	private String empDept;
	
	public Employee() {
		
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		if(empName==null || empName.length() <=0) {
			throw new IllegalArgumentException();
		}
		this.empName = empName;
	}

	public String getEmpDesign() {
		return empDesign;
	}

	public void setEmpDesign(String empDesign) throws NoDesignationFoundException {
		if( !(empDesign.equals("developer") || empDesign.equals("tester") 
				|| empDesign.equals("lead") || empDesign.equals("manager")) )
		{
			throw new NoDesignationFoundException("Invalid Designation");
		}
		this.empDesign = empDesign;
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) throws NoDepartmentFoundException {
		if( !(empDept.equals("TTH") || empDept.equals("RCM") || 
				empDept.equals("Digital") || empDept.equals("DevOps")) )
		{
			throw new NoDepartmentFoundException("Invalid Dept");
		}
		this.empDept = empDept;
	}

	public Employee(int empId, String empName, String empDesign, String empDept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDesign = empDesign;
		this.empDept = empDept;
	}

	public String print() {
		return "Employee: empId=" + empId + ",\n empName=" + empName + ",\n empDesign=" + empDesign + ",\n empDept=" + empDept
				+ "]";
	}

}
