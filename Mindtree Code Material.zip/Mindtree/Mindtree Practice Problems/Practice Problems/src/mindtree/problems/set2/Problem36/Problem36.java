package mindtree.problems.set2.Problem36;

import java.util.Scanner;

public class Problem36 {

	public static int[] uniqElements(int[] arr1,int[] arr2) {
		
//		for()
		return null;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter no of elements in 1st array\n");
		int n1=sc.nextInt();
		int[] arr1=new int[n1];
		for(int i=0;i<n1;i++)
		{
			arr1[i]=sc.nextInt();
		}
		System.out.print("Enter no of elements in 2nd array\n");
		int n2=sc.nextInt();
		int[] arr2=new int[n2];
		for(int i=0;i<n2;i++)
		{
			arr2[i]=sc.nextInt();
		}

		for(int i=0;i<uniqElements(arr1, arr2).length;i++)
		{
			System.out.println(""+uniqElements(arr1,arr2)+" ");
		}
		
		sc.close();
	}

}
