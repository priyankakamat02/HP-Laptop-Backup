package mindtree.problems.set2.Problem31;

public class InvalidRatingException extends Exception{

	private static final long serialVersionUID = 1L;
	public InvalidRatingException(String message) {
		super(message);
	}

}
