package mindtree.problems.set2.Problem33;

public class Student {
	private int studentId;
	private String studentName;
	private float marks;
	private boolean secondChance;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int studentId, String studentName, float marks, boolean secondChance) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
		this.secondChance = secondChance;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public float getMarks() {
		return marks;
	}

	public void setMarks(float marks) {
		this.marks = marks;
	}

	public boolean isSecondChance() {
		return secondChance;
	}

	public void setSecondChance(boolean secondChance) {
		this.secondChance = secondChance;
	}
	
	public void identifyMarks(float marks) {
		if(!(marks<35))
		{
			System.out.print("Student cleared the exam");
			secondChance=false;
		}
		else
		{
			System.out.println("Reattempt! Student hasn't cleared the exam.");
			secondChance=true;
		}

	}
	
//	public void identifyMarks(float marks,float ) {
//		
//
//	}

}
