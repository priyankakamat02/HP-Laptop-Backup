package mindtree.problems.set2.Problem30;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		SavingsAccount sa=new SavingsAccount();
		sa.setBalance(sc.nextDouble());
		sa.setInterestRate(sc.nextInt());
		sa.setAccountNo(sc.nextInt());
		try {
			sa.withDraw(sc.nextDouble());
		} catch (InsufficientBalanceException e) {
			e.printStackTrace();
		}
		sc.close();
	}

}
