package mindtree.problems.set2.Problem27;

public class NoDepartmentFoundException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public NoDepartmentFoundException(String message) {
		super(message);
	}

}
