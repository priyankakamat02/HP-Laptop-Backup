package mindtree.problems.set2.Problem32;

public class Manager {

	private Employee manages[];
	public Manager() {
		
	}
	
	public Manager(Employee[] manages) {
		super();
		this.manages = manages;
	}

	public Employee[] getManages() {
		return manages;
	}

	public void setManages(Employee[] manages) {
		this.manages = manages;
	}
	
	public void addTeamMembers() {
		

	}
	
	private Employee[] getTeamMembers() {
		return manages;

	}

}
