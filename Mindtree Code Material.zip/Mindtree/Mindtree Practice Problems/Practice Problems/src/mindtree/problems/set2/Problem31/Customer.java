package mindtree.problems.set2.Problem31;

public class Customer {

	private String name;
	private String mobileNo;
	private double feedbackRating;
	
	public Customer() {
		
	}

	public Customer(String name, String mobileNo, double feedbackRating) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.feedbackRating = feedbackRating;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getFeedbackRating() {
		return feedbackRating;
	}

	public void setFeedbackRating(double feedbackRating) throws InvalidRatingException {
		if(feedbackRating > 5.0)
		{
			throw new InvalidRatingException("Invalid Rating! PLease give valid rating");
		}
		this.feedbackRating = feedbackRating;
	}
	
	public String print() {
		
		return "Customer:\n Customer name: "+name+"\n Mobile No: "+mobileNo+"\n Feedback Rating: "+feedbackRating;
	}

}
