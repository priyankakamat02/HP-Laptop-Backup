package mindtree.problems.set2.Problem27;

public class NoDesignationFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public NoDesignationFoundException(String message) {
		super(message);
	}

}
