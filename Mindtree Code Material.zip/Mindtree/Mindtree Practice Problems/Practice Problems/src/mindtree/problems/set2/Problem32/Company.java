package mindtree.problems.set2.Problem32;

public class Company {

	private String name;
	private Employee employees[];
	
	public Company() {
		
	}

	public Company(String name, Employee[] employees) {
		super();
		this.name = name;
		this.employees = employees;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Employee[] getEmployees() {
		return employees;
	}

	public void setEmployees(Employee[] employees) {
		this.employees = employees;
	}
	
	

}
