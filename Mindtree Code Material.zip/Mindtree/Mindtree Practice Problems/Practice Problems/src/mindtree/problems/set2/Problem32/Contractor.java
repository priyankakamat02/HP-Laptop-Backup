package mindtree.problems.set2.Problem32;

import java.util.Date;

public class Contractor {

	private Date lengthOfContract;
	
	public Contractor() {
		
	}

	public Contractor(Date lengthOfContract) {
		super();
		this.lengthOfContract = lengthOfContract;
	}

	public Date getLengthOfContract() {
		return lengthOfContract;
	}

	public void setLengthOfContract(Date lengthOfContract) {
		this.lengthOfContract = lengthOfContract;
	}
	
	

}
