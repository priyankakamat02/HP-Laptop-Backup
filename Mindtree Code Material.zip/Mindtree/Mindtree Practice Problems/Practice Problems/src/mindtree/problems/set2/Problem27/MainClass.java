package mindtree.problems.set2.Problem27;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		Employee emp=new Employee();
		emp.setEmpId(sc.nextInt());
		emp.setEmpName(sc.next());
		try {
			emp.setEmpDesign(sc.next());
		} catch (NoDesignationFoundException e) {
			e.printStackTrace();
		}
		try {
			emp.setEmpDept(sc.next());
		} catch (NoDepartmentFoundException e) {
			e.printStackTrace();
		}

		System.out.print(emp.print());
		sc.close();
	}

}
