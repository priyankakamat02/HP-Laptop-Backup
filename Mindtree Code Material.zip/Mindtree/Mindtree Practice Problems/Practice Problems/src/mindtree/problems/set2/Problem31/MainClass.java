package mindtree.problems.set2.Problem31;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int N=sc.nextInt();
		Customer cust[]=new Customer[N];
		for(int i=0;i<N;i++)
		{
			cust[i]= new Customer(sc.next(),sc.next(),sc.nextDouble());
		}
		for(int i=0;i<N;i++)
		{
			System.out.println(cust[i].print());
		}
		
		sc.close();
	}

}
