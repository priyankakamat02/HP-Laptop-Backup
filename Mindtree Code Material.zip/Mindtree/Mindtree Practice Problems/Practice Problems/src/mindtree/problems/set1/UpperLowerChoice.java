package mindtree.problems.set1;

import java.util.Scanner;

public class UpperLowerChoice {
	static Scanner sc = new Scanner(System.in);
	static String newStr = "";
	
	public static void upperToLower() {
		System.out.print("Enter the String:");
		String str = sc.next();
		for (int i = 0; i < str.length(); i++) {
			char aChar = str.charAt(i);

			if ((int) (aChar) >= 65 && (int) (aChar) <= 90) {
				aChar = (char) (aChar + 32);

			}
			newStr = newStr + aChar;
		}
		System.out.print(newStr);
	}
	
	public static void lowerToUpper() {
		System.out.print("Enter the String:");
		String str = sc.next();
		for (int i = 0; i < str.length(); i++) {
			char aChar = str.charAt(i);

			if ((int) (aChar) >= 97 && (int) (aChar) <= 122) {
				aChar = (char) (aChar - 32);

			}
			newStr = newStr + aChar;
		}
		System.out.print(newStr);
	}
	
	public static void main(String[] args) {
		int ch=0;
		System.out.println("Enter the valid choice");
		ch=sc.nextInt();
		switch (ch) {
		case 1:
			upperToLower();
			break;
		case 2:
			lowerToUpper();
			break;

		default:
			break;
		}
		sc.close();
	}

}
