package mindtree.problems.set1;

public class PrintCntOccurence {

	public static void main(String[] args) {
		String[] strArray= {"abc","ab","abc","ab","abc","ad"};
		int cnt;
		for(int i=0;i<strArray.length;i++)
		{
			cnt=0;
			for(int j=0;j<strArray.length;j++)
			{
				if(strArray[i]==strArray[j])
				{
					cnt++;
				}
				strArray[j]="";  
			}
			System.out.println(""+strArray[i]+" "+cnt);
			  
		}

	}

}
