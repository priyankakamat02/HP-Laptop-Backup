package mindtree.problems.set1;
import java.util.Scanner;

public class Problem19 {

	public static void main(String[] args) {
		/*
		 * We have 2 student names Ali Al-Ali and Ahmed Al-Ahmed. Design and implement a
		 * Java program that will exchange the last name of the two students in such a
		 * way that the new names are going to be Ali Al-Ahmed and Ahmed Al-Ali. NOTE:
		 * Your program should work for any names NOT ONLY these given names in the
		 * exercise.
		 */
		
		Scanner sc =  new Scanner(System.in);
		
		String[] str1 = new String[2];
		String[] str2 = new String[2];
		
		for(int i = 0; i < str1.length; i++) {
			
			str1[i] = sc.next();
		}
		
		for(int i = 0; i < str2.length; i++) {
			
			str2[i] = sc.next();
		}
		
		String temp;
		
		temp = str1[1];
		str1[1] = str2[1];
		str2[1] = temp;
		
		for(String name : str1) {
			
			System.out.print(name + " ");
		}
		
		for(String name : str2) {
			
			System.out.print(name + " ");
		}
		sc.close();
	}

}
