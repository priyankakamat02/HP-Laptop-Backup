package mindtree.problems.set1;
import java.util.Scanner;

public class Problem16 {
	
	public static void display(String str[], int n) {

        System.out.print("\t");

        for (int i = 0; i < n; i++) {

            System.out.print(str[i] + " ");

        }

        System.out.println();
    }
	
	public static String[] bubble(String str[], int n) {

        String temp;
        
        boolean isSorted = false;

        for (int i = 0; i < n - 1; i++) {

            isSorted = true;
             
            for (int j = 0; j < n - 1; j++) {

                if (str[j].compareTo(str[j + 1]) > 0) {

                    temp = str[j];
                    str[j] = str[j + 1];
                    str[j + 1] = temp;
                    
                    isSorted = false;

                }
            }
            
            if (isSorted) {
                break;
            }
        }
        
        return str;
    }
	
	static String[] insertion(String[] str, int n) {

        int j;
        
        String key;

        for (int i = 1; i < n; i++) {
            
            key = str[i];
            j = i - 1;

            while (j >= 0 && str[j].compareTo(key) > 0) {
                str[j + 1] = str[j];
                j--;
            }
            str[j + 1] = key;

        }
        
        return str;
    }

	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		
		System.out.print("Enter the total number of string you want to enter in array: ");
		
		int n1 = sc.nextInt();
		String[] str = new String[n1];
		
		for(int i = 0; i < n1; i++) {
			
			str[i] = sc.next();
		}
		
		System.out.println("Menu:");
		System.out.println("\t 1. Sort using bubble sort");
		System.out.println("\t 2. Sort using insertion sort");
		System.out.println("\t 3. Exit");
		
		int choice = sc.nextInt();
		
		switch(choice){
			
		case 1:
			
			str = bubble(str, str.length);
			display(str, str.length);
			break;
		
		case 2:
			
			str = insertion(str, str.length);
			
			display(str, str.length);
			
			break;
		
		case 3:
			
			System.exit(0);
			
			break;
			
		default:
			System.out.println("Enter valid choice");
			
		}
	}

}
