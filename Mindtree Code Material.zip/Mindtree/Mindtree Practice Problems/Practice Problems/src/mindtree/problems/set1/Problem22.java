package mindtree.problems.set1;

import java.util.Scanner;

public class Problem22 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter sentance");
		String sentance=sc.nextLine();
		sentance+=' ';
		String result=Convertstring(sentance);
		System.out.println(result);
		sc.close();
	}

	static String Convertstring(String str) {
		int len=str.length();
		String result="";
		for(int i=0;i<len;i++) {
			String word="";
			for(;i<len;i++) {
				if(str.charAt(i)==' '||str.charAt(i)=='.') {
					
					result+=validate(word);
					
					if(str.charAt(i)==' ') {
						result+=' ';
					}
					else if(str.charAt(i)=='.') {
						result+='.';
					}
					break;
				}else {
					char temp=str.charAt(i);
					word+=temp;
				}
			}
			//result+=' ';
		}
		return result;
	}

	static String validate(String word) {
		int len=word.length();
		String res = word;
		boolean ver=true;
		for(int i=0;i<len;i++) {
			int temp=word.charAt(i);
			if(temp<=60&&temp>47) {
				ver=false;
			}	
		}
		if(ver) {
			res=reverse(word);
		}else {
			res=numcheck(word);
		}
		return res;
	}

	static String numcheck(String word) {
		int len=word.length();
		String res="";
		boolean check=false;
		for(int i=0;i<len;i++) {
			int temp=word.charAt(i);
			if(temp>60) {
				check=true;
			}
		}
		if(check) {
			String word1="";
			for(int i=0;i<len;i++) {
				int temp=word.charAt(i);
				if(temp<61) {
					word1+=word.charAt(i);
				}else {
					res+=word1;
					String tem="";
					for(;i<len;i++) {
						temp=word.charAt(i);
						if(temp>60) {
							tem+=word.charAt(i);
						}else if(temp<=60) {
							break;
						}
					}
					String remining_char=reverse(tem);
					res+=remining_char;
				}
			}
		}
		return res;
	}

	static String reverse(String word) {
		int len=word.length();
		String res="";
		for(int i=len-1;i>=0;i--) {
			char temp=word.charAt(i);
			res+=temp;
		}
		return res;
	}
}
