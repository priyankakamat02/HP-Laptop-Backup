package mindtree.problems.set1;

import java.util.Scanner;

public class Problem11 {

	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		
		String choice = sc.next();
		
		switch(choice){
			
		case "triangle":
			int base = sc.nextInt();
			int height = sc.nextInt();
			
			System.out.printf("%.2f", (double)(base  * height) / 2);
			
			break;
		
		case "rectangle":
			int width = sc.nextInt();
			int length = sc.nextInt();
			
			System.out.printf("%.2f", (double)width * length);
			
			break;
			
		case "square":
			int side = sc.nextInt();
			
			System.out.printf("%.2f", (double)side * side);
			
			break;
		
		case "circle":
			int radius = sc.nextInt();
			
			System.out.printf("%.2f", (double)3.14 * (radius * radius));
			
			break;
			
		default:
			System.out.println("Enter valid choice");
			
		}
		sc.close();
	}

}
