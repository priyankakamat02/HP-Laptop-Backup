package mindtree.problems.set1;

import java.util.Scanner;

public class Problem1 {

	public static long factorial(int N) {
		long fact= 1L;
		for(int i=1;i<=N;i++)
		{
			fact=fact*i;
		}
		
		return fact;
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int num=sc.nextInt();
		System.out.print("Factorial of a given number is "+factorial(num));
		sc.close();
	}

}
