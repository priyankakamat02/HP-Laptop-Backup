package mindtree.problems.set1;
import java.util.Scanner;

public class Problem23 {
	public static String upperToLower(String S) {
		String newStr="";
		for (int i = 0; i < S.length(); i++) {
			char aChar = S.charAt(i);

			if ((int) (aChar) >= 65 && (int) (aChar) <= 90) {
				aChar = (char) (aChar + 32);

			}
			newStr = newStr + aChar;
		}
		return newStr;
	}
	
	public static void printConsecutiveCharacters(String St) {
		int size=1,j=0;
		String[] strArray=new String[10];
		for(int i=0;i<St.length()-size;i++)
		{
			char aChar1 = St.charAt(i);
			char aChar2 = St.charAt(i+1);
			if( ( (int) (aChar1) -(int) (aChar2) ) == (-1)  ) {
				strArray[j]=St.charAt(i)+""+St.charAt(i+1);
				System.out.print(""+strArray[j]+",");
				j++;
			}
		}
//		for(int i=0;i<strArray.length;i++)
//		{
//			int cnt=0;
//			if(strArray[i].equals())
//			{
//				
//			}
//		}
		
	}
	
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		printConsecutiveCharacters(upperToLower(str));
		sc.close();
	}


}
