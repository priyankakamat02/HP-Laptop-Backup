package mindtree.problems.set1;

import java.util.Scanner;

public class Problem5 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n1=sc.nextInt();
		double[] arr1 = new double[n1];
		for(int i=0; i<n1; i++)  
		{  
		//reading arr1 elements from the user   
			arr1[i]=sc.nextDouble(); 
		}  
		
		int n2=sc.nextInt();
		double[] arr2 = new double[n2];
		for(int i=0; i<n2; i++)  
		{  
		//reading arr2 elements from the user   
			arr2[i]=sc.nextDouble(); 
		} 
		
		int[] result = new int[arr2.length];
		
		for (int i = 0; i < arr2.length; i++) {
			
			if(i > arr1.length-1) {
				
				result[i] = (int)arr2[i];
			}else {
				
				result[i] = (int)arr1[i] + (int)arr2[i];
			}
		}
		
		for(int n : result) {
			System.out.println(n);
		}

		sc.close();
	}

}
