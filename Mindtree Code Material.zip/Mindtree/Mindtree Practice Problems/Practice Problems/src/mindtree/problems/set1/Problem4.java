package mindtree.problems.set1;

import java.util.Scanner;

public class Problem4 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		int sum=0;
		int[] arr =new int[n];

		
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
			sum=sum+arr[i];
		}
		System.out.print("sum of elements in array is: "+sum);
		sc.close();
	}

}
