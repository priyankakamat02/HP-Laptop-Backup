package mindtree.problems.set1;

import java.util.Scanner;

public class Problem6 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String name=sc.next();
		System.out.print("Hello, "+name+"!");
		sc.close();

	}

}
