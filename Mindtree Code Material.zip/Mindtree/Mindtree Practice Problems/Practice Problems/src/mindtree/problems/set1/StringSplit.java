package mindtree.problems.set1;

public class StringSplit {

	
	public void split(String str, char del) {
		int curr=0, arrayptr=0;
		String res="";
		String[] arr= new String[7];
		while (curr < str.length()) {
			res= "";
		}

	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
