package mindtree.problems.set1;

import java.util.Scanner;

public class StringUpperLowerConv {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		String newStr = "";
		for (int i = 0; i < str.length(); i++) {
			char aChar = str.charAt(i);
			
			if ((int) (aChar) >= 65 && (int) (aChar) <= 90) {
				aChar = (char) (aChar + 32);
				
			} else if ((int) (aChar) >= 97 && (int) (aChar) <= 122) {
				aChar = (char) (aChar - 32);
			}
			
			newStr = newStr + aChar; 
		}

		System.out.print(newStr);
		sc.close();

	}

}
