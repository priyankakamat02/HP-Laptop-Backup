package mindtree.problems.set1;

import java.util.Scanner;

public class Problem3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		if (n < 0) {
			System.out.println("Please enter positive number.");
			System.exit(0);
		}

		int i = 0;

		while (n != 1) {

			if ((n & 1) == 0) {

				// even
				n = (n / 2);
				i++;
				System.out.println(n + " is even so i take half: " + n);
			} else {

				// odd
				n = (n * 3) + 1;
				i++;
				System.out.println(n + " is odd so i make (3n+1): " + n);
			}
		}
		System.out.println("There are total " + i + " steps to reach 1");

		sc.close();
	}

}
