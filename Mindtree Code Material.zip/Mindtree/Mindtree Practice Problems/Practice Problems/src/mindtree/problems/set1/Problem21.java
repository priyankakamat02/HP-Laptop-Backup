package mindtree.problems.set1;

public class Problem21 {
	
	static boolean checkPass(String password) {
		boolean checkLen = false;
		boolean firstNumber = false;
		boolean iscap = false;
        boolean isnum = false;
        boolean charCheck = false;
        boolean finalCheck = false;

        int len = password.length();

        char[] arr = new char[len];

        for (int i = 0; i < len; i++) {
            arr[i] = password.charAt(i);
        }

        if (len == 10) {
            checkLen = true;
        }

        if (arr[0] >= 49 && arr[0] <= 50) {
            firstNumber = true;
        }
        
        if ((arr[1] >= 65 && arr[1] <= 90) && (arr[2] >= 65 && arr[2] <= 90)) {
        	
        	iscap = true;
        }
        
        if ((arr[3] >= 48 && arr[3] <= 57) && (arr[4] >= 48 && arr[4] <= 57)) {
        	
        	isnum = true;
        }
        
        String s = arr[5] + "" + arr[6];
        
        if(s.compareTo("CS") == 0 || s.compareTo("IS") == 0 || s.compareTo("ES") == 0 || s.compareTo("ME") == 0) {
        	
        	charCheck = true;
        }
        
        if((arr[7] >= 48 && arr[7] <= 57) && (arr[8] >= 48 && arr[8] <= 57) && (arr[9] >= 48 && arr[9] <= 57)){
        	
        	finalCheck = true;
        }
        
        return (iscap && isnum && checkLen && firstNumber && charCheck && finalCheck);
    }

	public static void main(String[] args) {
		
		String password = "1DS09CS010";
        
        boolean result = checkPass(password);
        System.out.println((result == false) ? 0 : 1);
	}

}
