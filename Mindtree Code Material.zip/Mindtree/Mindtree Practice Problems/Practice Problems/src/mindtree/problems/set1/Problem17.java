package mindtree.problems.set1;

import java.util.Scanner;

public class Problem17 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String Fullname = sc.next();
		String newStr="";
		for(int i=0;i<Fullname.length();i++)
		{
			char aChar = Fullname.charAt(i);
			if((int) (aChar) >= 65 && (int) (aChar) <= 90)
			{
				newStr=newStr+Fullname.charAt(i);
			}
		}
		System.out.print(newStr);
		sc.close();
	}

}
