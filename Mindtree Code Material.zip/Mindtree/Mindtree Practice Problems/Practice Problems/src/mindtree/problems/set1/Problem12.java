package mindtree.problems.set1;

public class Problem12 {

	public static void display(int arr[], int n) {

        System.out.print("\t");

        for (int i = 0; i < n; i++) {

            System.out.print(arr[i] + " ");

        }

        System.out.println();
    }

    public static void bubble(int arr[], int n) {

        int temp;
        
        boolean isSorted = false;

        for (int i = 0; i < n - 1; i++) {

            System.out.println("Pass " + (i + 1) + ":");
            
            isSorted = true;
             
            for (int j = 0; j < n - 1; j++) {

                if (arr[j] > arr[j + 1]) {

                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    
                    isSorted = false;

                }

                display(arr, arr.length);

            }
            
            if (isSorted) {
                return;
            }
        }
    }

    public static void main(String[] args) {

        int[] arr = {5, 1, 4, 2, 8};

        bubble(arr, arr.length);
        
    }

}
