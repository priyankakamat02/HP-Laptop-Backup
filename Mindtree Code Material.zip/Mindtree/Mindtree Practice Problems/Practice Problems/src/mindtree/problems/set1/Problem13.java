package mindtree.problems.set1;
import java.util.Scanner;

public class Problem13 {
	
public static int[] sort(int[] arr) {
		
		int n = arr.length;

        for (int i = 0; i < n - 1; i++) {

            for (int j = 0; j < n - 1 - i; j++) {

                if (arr[j] > arr[j + 1]) {
                    int temp;

                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;

                }
            }
        }
        
        return arr;
    }
	
	public static boolean findElement(int arr[], int key) {
		
		int mid = 0;

        int flag = 0;
        
        int l = 0;
        
        int h = arr.length - 1;

        while (l <= h) {
            mid = (l + h) / 2;

            if (key == arr[mid]) {

                flag = 1;
                break;
            } else {

                if (key < arr[mid]) {
                    h = mid - 1;
                } else {
                    l = mid + 1;
                }
            }
        }
		
		return (flag == 0) ? false : true;
	}

	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		
		System.out.print("Enter the total number you want to enter in array: ");
		
		int n = sc.nextInt();
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			
			arr[i] = sc.nextInt();
		}
		
		System.out.print("Enter the number you want to search: ");
		
		int key = sc.nextInt();
		
		arr = sort(arr);
		
		System.out.println(findElement(arr, key));
	}

}
