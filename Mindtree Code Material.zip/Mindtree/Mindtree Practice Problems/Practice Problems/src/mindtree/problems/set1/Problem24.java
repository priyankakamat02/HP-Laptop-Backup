package mindtree.problems.set1;
import java.util.Scanner;

public class Problem24 {
	
	public static String upperToLower(String S) {
		String newStr="";
		for (int i = 0; i < S.length(); i++) {
			char aChar = S.charAt(i);

			if ((int) (aChar) >= 65 && (int) (aChar) <= 90) {
				aChar = (char) (aChar + 32);

			}
			newStr = newStr + aChar;
		}
		return newStr;
	}
	
	public static void countEachChar(String Str) {
		int counter[] = new int[256]; 
		int len = Str.length();
		for (int i = 0; i < len; i++) 
			counter[Str.charAt(i)]++;
		
		char array[] = new char[Str.length()];
		for (int i = 0; i < len; i++) { 
			   array[i] = Str.charAt(i); 
			   int flag = 0; 
			   for (int j = 0; j <= i; j++) { 
				   if (Str.charAt(i) == array[j])  
					   flag++;                 
			   }
			   if (flag == 1)  
				      System.out.print("" + Str.charAt(i)+ "" + counter[Str.charAt(i)]);
		}
		
		
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		countEachChar(upperToLower(str));
		sc.close();
	}

}
