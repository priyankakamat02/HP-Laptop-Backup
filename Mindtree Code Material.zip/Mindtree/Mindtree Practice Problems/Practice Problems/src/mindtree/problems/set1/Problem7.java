package mindtree.problems.set1;

import java.util.Scanner;

public class Problem7 {

	public static int GetMax(int a, int b, int c)
	{
		int max = (a > b) ?(a > c ? a : c) :(b > c ? b : c);
		return max;
	}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		System.out.print(GetMax(a,b,c));
		sc.close();
	}

}
