package mindtree.problems.set1;

import java.util.Scanner;

public class Problem2 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int input=sc.nextInt();
		for(int i=1;i<=12;i++)
		{
			System.out.println(""+input+" * "+i+" = "+(input*i));
		}
		sc.close();
	}

}
