package mindtree.problems.set1;

import java.util.Scanner;

public class Problem8 {

	public static int numReverse(int N) {
		int rev = 0;
		while (N != 0) {
			int digit = N % 10;
			rev = rev * 10 + digit;
			N = N / 10;
		}

		return rev;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		System.out.print(numReverse(num));
		sc.close();

	}

}
