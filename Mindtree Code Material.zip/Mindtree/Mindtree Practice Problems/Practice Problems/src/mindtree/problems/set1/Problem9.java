package mindtree.problems.set1;

import java.util.Scanner;

public class Problem9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		boolean flag = false;

		if (num == 0 || num == 1) {
			System.out.print("false");
		} else {
			for (int i = 2; i <= num / 2; i++) {
				if (num % i == 0) {
					flag = true;
					break;
				}
			}
			if (!flag)
				System.out.print("true");
			else
				System.out.print("false");

		}
		sc.close();
	}

}
