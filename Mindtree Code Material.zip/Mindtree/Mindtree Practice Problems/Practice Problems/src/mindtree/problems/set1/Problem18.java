package mindtree.problems.set1;

import java.util.Scanner;

public class Problem18 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String password = "";
		
		String first = sc.next();
		String middile = sc.next();
		String last = sc.next();
		
		int age = sc.nextInt();
		
		password = first.charAt(0)+ "" + middile.charAt(0) + "" + last.charAt(0) + "" + age;
		
		System.out.println(password);
		sc.close();
		
	}

}
