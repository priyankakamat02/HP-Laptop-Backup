package mindtree.problems.set1;

public class Problem20 {
	
	public String value;
	
	Problem20(String value){
		
		this.value = value;
	}
	
	public int compareTo(String anotherString) {
		
		int len1 = value.length();
		int len2 = anotherString.length();
		int lim = Math.min(len1, len2);
		
		char v1[] = value.toCharArray();
		char v2[] = anotherString.toCharArray();
		
		int k = 0;
		
		while( k < lim ) {
			
			char c1 = v1[k];
			char c2 = v2[k];
			if(c1 != c2) {
				
				return c1 - c2;
			}
			
			k++;
		}
		
		return len1 - len2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Problem20 s = new Problem20("Vinayak");
		System.out.println(s.compareTo("Vinayak"));
	}

}
