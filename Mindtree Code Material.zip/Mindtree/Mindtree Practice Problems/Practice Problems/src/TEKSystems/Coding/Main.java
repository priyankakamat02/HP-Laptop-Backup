package TEKSystems.Coding;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter the number:");
		int n= sc.nextInt();
		int arr[]= new int[n];
		for(int i=0; i<n;i++)
		{
			if(i%2==0)
			{
				arr[i]=i+1;
			}
		}
		int r=3;
		while (r < arr.length) {
			int c=0;
			for (int i = 0; i < n; i++) {
				
				if(arr[i]!=0)
				{
					c++;
				}
				if(c==r)
				{
					arr[i]=0;
				}
			}
			r++;
		}
		if(arr[n-1]!=0)
		{
			System.out.println("Yes");
		}
		else {
			System.out.println("No");
		}
		sc.close();
	}

}
