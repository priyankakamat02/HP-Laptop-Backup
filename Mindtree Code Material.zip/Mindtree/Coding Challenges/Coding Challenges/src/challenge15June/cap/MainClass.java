package challenge15June.cap;

import java.util.Scanner;

public class MainClass {

	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter the no. of Cars: ");
		int n= sc.nextInt();
		Car[] car = new Car[n];
		for(int i=0;i<car.length;i++)
		{
			System.out.println();
			System.out.println("Enter the ID of Car No "+(i+1));
			int ID= sc.nextInt();
			System.out.println("Enter the Name of Car No "+(i+1));
			String name= sc.next();
			System.out.println("Enter the Price of Car No "+(i+1));
			double price= sc.nextDouble();
			Car obj= new Car(ID,name,price);
			car[i]=obj;
		}
		while(true) 
		{
			menu();
			System.out.println("Enter your choice: ");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				displayCars(car);
				break;
			case 2:
				Car[] sortResultByPrice = sortCarByPrice(car);
				displayCars(sortResultByPrice);
				break;
			case 3:
				Car[] sortResultByName = sortCarByName(car);
				displayCars(sortResultByName);
			case 4:
				binarySearch(car);
				break;
			case 5:
				Car[] updatePrice = updatePrice(car);
				displayCars(updatePrice);
				break;
				
			case 6:
				System.out.print("Thank You !!!");
				System.exit(0);
				break;
			default:
				System.out.println("Incorrect choice !!!");
			}
		}
		
	}
	
	public static void binarySearch(Car[] car) {
		sortCarByPrice(car);
		System.out.println("Enter the name to search: ");
		String name=sc.next();
		int start=0, end=car.length, mid=(start+end)/2;
		while(start<=end)
		{
			if(name.compareTo(car[mid].getName())==0) {
				System.out.println("Car found at position "+(mid+1));
				break;
			}
			if(name.compareTo(car[mid].getName())>0)
			{
				start=mid;
			}
			else
			{
				end=mid;
			}
			mid=(start+end)/2;
			
		}
		if(start > end)
		{
			System.out.println("Car not found");
		}

	}
	
	public static Car[] sortCarByPrice(Car[] car) {
		for(int i=0; i<car.length;i++)
		{
			Car temp = car[i];
			int j=i-1;
			while(j>=0 && (car[j].getPrice())>temp.getPrice())
			{
				car[j+1]=car[j];
				j--;
			}
			car[j+1]=temp;
		}
		return car;
	}
	
	private static Car[] sortCarByName(Car[] car) {
		for (int i = 0; i < car.length; i++) {
			Car check = car[i];
			int j = i - 1;
			while (j >= 0 && car[j].getName().compareTo(check.getName())>0) {
				car[j + 1] = car[j];
				j--;

			}
			car[j + 1] = check;

		}
		return car;
	}
	
	private static Car[] updatePrice(Car[] car) {
		System.out.println("Enter the value:");
		float n= sc.nextFloat();
		System.out.println("Enter the Car name:");
		String name= sc.next();
		for(int i=0;i< car.length;i++)
		{
			if(car[i].getName().equals(name))
			{
				car[i].setPrice((100+n)/100 * car[i].getPrice());
			}
			
			//car[i].setPrice(1.1 * car[i].getPrice());
		}
		
		return car;

	}
	public static void displayCars(Car[] car) {
		System.out.println("Car Details:");
		for(int i=0;i<car.length;i++)
		{
			System.out.println("Car No: "+(i+1)+" ID is: "+car[i].getId());
			System.out.println("Car No: "+(i+1)+" Name is: "+car[i].getName());
			System.out.println("Car No: "+(i+1)+" Price is: "+car[i].getPrice());
			System.out.println();
		}

	}
	
	public static void menu() {
		System.out.println();
		System.out.println("_*_*_MENU_*_*_");
		System.out.println("(1) Display all the Cars");
		System.out.println("(2) Sort the Cars by price");
		System.out.println("(3) Sort the cars by Name");
		System.out.println("(4) Binary Search");
		System.out.println("(5) Update Price");
		System.out.println("(6) Exit");
		System.out.println();

	}

}
