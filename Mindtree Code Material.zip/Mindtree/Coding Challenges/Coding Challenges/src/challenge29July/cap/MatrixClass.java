package challenge29July.cap;

import java.util.Scanner;

public class MatrixClass {

	private static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Enter the row size: ");
		int row = sc.nextInt();
		System.out.println("Enter the column size: ");
		int col = sc.nextInt();
		implementArray(row, col);
	}
	
	public static void implementArray(int row, int col) {
		int array[][] = new int[row][col];
		System.out.println("Enter the elements: ");
		for(row =0;row< array.length; row++)
		{
			for(col =0; col< array.length;col++)
			{
				array[row][col]= sc.nextInt();
			}
		}
		System.out.println("Input array: ");
		for(int i=0; i< array.length;i++)
		{
			for(int j=0; j< array.length; j++)
			{
				System.out.print(array[i][j]+" ");
			}
			System.out.println();
		}
		
		int resultArr[][] = modifyArray(array, row,col);
		System.out.println("Output is: ");
		for(int i=0; i< resultArr.length;i++)
		{
			for(int j=0; j< resultArr.length;j++)
			{
				System.out.print(resultArr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static int[][] modifyArray(int[][] array,int row,int col) {
		for(int i=0;i< array.length;i++)
		{
			int temp = array[i][i];
			array[i][i]= array[0][i];
			array[0][i]= temp;
		}
		return array;
	}

}
