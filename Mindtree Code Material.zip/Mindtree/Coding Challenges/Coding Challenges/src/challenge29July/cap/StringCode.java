package challenge29July.cap;

import java.util.Scanner;

public class StringCode {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
		String ar[] = splitFunc(str);
		String senc = sentenceLogic(ar);
		System.out.println(senc);

	}

	public static String sentenceLogic(String[] sentt) {
		String sent = "", s1 = "", s2 = "", s3 = "", s4 = "";
		s1 = sentt[0];
		s2 = sentt[1];
		s3 = s3 + (char) s1.charAt(0);
		for (int i = 1; i < s1.length() - 1; i++) {
			s3 = s3 + (char)s2.charAt(i);
		}
		s3 = s3 + (char)s1.charAt(s1.length() - 1);
		s4 = s4 + (char)s2.charAt(0);
		for (int i = 1; i < s2.length() - 1; i++) {
			s4 = s4 + (char) s1.charAt(i);
		}
		s4 = s4 + (char) s2.charAt(s2.length() - 1);
		sent = s3 + " " + s4;
		return sent;
	}

	public static String[] splitFunc(String s) {
		int n = s.length();
		int c = 0;
		for (int i = 0; i < n; i++) {
			if (s.charAt(i) == ' ') {
				c++;
			}
		}
		String ar[] = new String[c + 1];
		String t = "";
		int j = 0;
		for (int i = 0; i < n; i++) {
			if (s.charAt(i) == ' ') {
				ar[j] = t;
				j++;
				t = "";
			} else if (i == n - 1) {
				t += s.charAt(i);
				ar[j] = t;
			} else {
				t += s.charAt(i);
			}
		}
		
		return ar;
	}

}
