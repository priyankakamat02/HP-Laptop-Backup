package challenge27July.cap;

import java.util.Scanner;

public class ProductApplication {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter the no. of products: ");
		int n = sc.nextInt();
		Product[] prod = new Product[n];
		for(int i=0; i< prod.length; i++)
		{
			System.out.println();
			System.out.println("Enter the Id of product no: "+(i+1));
			short id = sc.nextShort();
			System.out.println("Enter the name of product no: "+(i+1));
			String name = sc.next();
			System.out.println("Enter the price of product no: "+(i+1));
			float price = sc.nextFloat();
			System.out.println("Enter the Quantity of product no: "+(i+1));
			int quantity = sc.nextInt();
			
			Product prods = new Product(id, name, price, quantity);
			prod[i]= prods;
		}
		
		boolean flag = true;
		do {
			mainMenu();
			System.out.println("Enter the choice:");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				displayProducts(prod);
				break;
				
			case 2:
				Product[] sortByPrice = sortProductsUsingPrice(prod);
				displayProducts(sortByPrice);
				break;
				
			case 3:
				
				int result = updateProductQuantity(prod);
				if(result < 0)
				{
					System.out.println("Invalid Product Id");
				}
				else
				{
					System.out.println("Enter the new quantity to update: ");
					int quantity  = sc.nextInt();
					prod[result].setQuantity(quantity);
					System.out.println("Quantity updated successfully");
				}
				break;
				
			case 4:
				System.out.println("Thank you !!");
				flag = false;
				break;

			default:
				System.out.println("Invalid choice !!!");
				break;
			}
			
		} while (flag);

	}
	
	public static void mainMenu() {
		System.out.println();
		System.out.println("**MENU**");
		System.out.println("(1) Display the details");
		System.out.println("(2) Sort products based on Price:");
		System.out.println("(3) Update product quantity:");
		System.out.println("(4) Exit");

	}
	
	public static void displayProducts(Product[] prod)
	{
		System.out.println("Product details:");
		for(int i=0; i<prod.length; i++)
		{
			System.out.println("Product No: "+(i+1)+" Id is "+prod[i].getId());
			System.out.println("Product No: "+(i+1)+" Name is "+prod[i].getName());
			System.out.println("Product No: "+(i+1)+" Price is "+prod[i].getPrice());
			System.out.println("Product No: "+(i+1)+" Quantity is "+prod[i].getQuantity());
			System.out.println();
		}
	}
	
	public static Product[] sortProductsUsingPrice(Product[] prod) {
		for(int i=0; i<prod.length; i++)
		{
			Product temp = prod[i];
			int j = i-1;
			while (j >= 0 && (prod[j].getPrice()) > temp.getPrice())
			{
				prod[j + 1] = prod[j];
				j--;
			}
			prod[j+1] = temp;
		}
		return prod;
	}
	
	public static Product[] sortProductById(Product[] product) {
		for (int i = 0; i < product.length; i++) {
			Product temp = product[i];
			int j = i - 1;
			while (j >= 0 && (product[j].getId()) > temp.getId()) {
				product[j + 1] = product[j];
				j--;
			}
			product[j + 1] = temp;
		}
		return product;
	}
	
	private static int updateProductQuantity(Product[] prod)
	{
		sortProductById(prod);
		System.out.println("Enter the Id of product: ");
		short id = sc.nextShort();
		int first = 0;
		int last = prod.length - 1;
		int mid =0;
		
		while (first <= last)
		{
			mid = (first + last)/2;
			if(prod[mid].getId() < id)
			{
				first = mid + 1;
			}
			else if(prod[mid].getId() == id)
			{
				
				return mid;
			}
			else {
				last = mid -1;
			}
		}
		return -1;
		
	}

}
