package challenge1.cap4;

import java.util.Scanner;

public class Contacts {
	private int id;
	private String contactName;
	private String contactNo;
	static Scanner sc= new Scanner(System.in);
	
	public Contacts(int id, String contactName, String contactNo) {
		super();
		this.id = id;
		this.contactName = contactName;
		this.contactNo = contactNo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	public  void display() {
		System.out.println("Contact Id: "+id+" "+"Contact Name: "+contactName+" "+"Contact Number: "+contactNo);
		System.out.println();
	}
	
	public static void displayContacts(Contacts[] con) {
		for(int i=0;i<con.length;i++)
		{
			System.out.println("Contact "+(i+1)+": ");
			con[i].display();
			System.out.println("");
		}

	}
	
	public static void sortContactsByName(Contacts[] con) {
		for(int i=0;i<con.length;i++)
		{
			Contacts temp=con[i];
			int j=i-1;
			while(j>=0 && con[j].contactName.compareTo(temp.contactName)>0)
			{
				con[j+1]=con[j];
				j--;
			} con[j+1]=temp;
		}
		displayContacts(con);
	}
	
	public static void searchByName(Contacts[] con) {
		System.out.println("Enter the name to search: ");
		String name= sc.next();
		int index= -1;
		for(int i=0;i<con.length;i++)
		{
			if(name.equals(con[i].contactName))
				index=i+1;
		}
		if(index>=0)
			System.out.println("Contact is found at position "+(index));
		else
			System.out.println("Contact not found");
	}
	
	public static void updateContact(Contacts[] con) {
		System.out.println("Enter the person name to update: ");
		String name= sc.next();
		System.out.println("Enter the new number: ");
		String number=sc.next();
		for(int i=0;i<con.length;i++)
		{
			if(name.equals(con[i].contactName))
				con[i].contactNo=number;
		}
		displayContacts(con);
	}

}
