package challenge1.cap4;

import java.util.Scanner;
import challenge1.cap4.Contacts;

public class Problem1 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the no of Contacts: ");
		int n = sc.nextInt();
		Contacts[] con= new Contacts[n];
		for(int i=0; i<n ;i++)
		{
			System.out.println("Enter the contact no "+(i+1));
			con[i]=new Contacts(sc.nextInt(),sc.next(),sc.next());
		}
		while(true)
		{
			System.out.println("*/*_PHONE CONTACTS_*/*");
			System.out.println("1.Display all contacts present in the phone");
			System.out.println("2.Sort all contacts by their name and display");
			System.out.println("3.Search and display position of a contact, searched by its name");
			System.out.println("4.Update contact number of a particular contact");
			System.out.println("5.Exit");
			int choice= sc.nextInt();
			switch (choice) {
			case 1:
				
				break;

			default:
				break;
			}
		}
		
	}

}
