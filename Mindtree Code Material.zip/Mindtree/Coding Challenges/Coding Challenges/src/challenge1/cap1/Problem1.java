package challenge1.cap1;

import java.util.Scanner;

public class Problem1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num1= sc.nextInt();
		int num= num1;
		int cnt=0;
		do {
			cnt++;
			num/=10;
		} while (num!=0);
		System.out.println(cnt);
		num=num1;
		int rev=0;
		if(cnt%2==0)
		{
			int r=0;
			do {
				if(r-1 == cnt/2)
				{
					rev*=10;
				}
				r=num%10;
				rev=(rev*10)+r;
				num/=10;
			} while (num!=0);
		}
		else {
			do {
				int r=num%10;
				rev=(rev*10)+r;
				num/=10;
			} while (num!=0);
		}
		System.out.println(rev);
		sc.close();
	}

}
