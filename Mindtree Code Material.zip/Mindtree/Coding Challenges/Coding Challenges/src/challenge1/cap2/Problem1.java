package challenge1.cap2;

import java.util.Scanner;

public class Problem1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the rowsize: ");
		int row_size = sc.nextInt();
		System.out.print("Enter the colsize: ");
		int col_size = sc.nextInt();
		System.out.print("Enter the 2D array: ");
		int [][] arr2D = new int[row_size][col_size];
		int [] arr1D= new int[row_size];
		for(int i=0;i<row_size;i++)
		{
			int sum=0;
			for(int j=0; j<col_size;j++)
			{
				arr2D[i][j]=sc.nextInt();
				sum += arr2D[i][j];
			}
			arr1D[i]=sum;
		}
		System.out.print("The required 1D array is:\n");
		for(int i=0;i<row_size;i++)
			System.out.print(arr1D[i]+" ");
		sc.close();
	}

}
