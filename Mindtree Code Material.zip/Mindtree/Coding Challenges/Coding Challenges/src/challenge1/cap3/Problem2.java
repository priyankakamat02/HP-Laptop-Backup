package challenge1.cap3;

import java.util.Scanner;

public class Problem2 {

	public static int linearSearch(int[] arr,int key) {
		for(int i=0; i<arr.length; i++)
		{
			if(arr[i]==key)
			{
				return i;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int [] arr= {5, 8, 3, 9, 2};
		System.out.println("Enter the element: ");
		int num= sc.nextInt();
		if(linearSearch(arr, num)!= -1)
			System.out.println("Element "+num+" is found at index: "+linearSearch(arr,num));
		else
			System.out.println("Element not found");
		sc.close();
	}

}
