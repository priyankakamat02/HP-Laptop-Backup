package challenge1.cap3;

import java.util.Arrays;
import java.util.Scanner;

public class Problem1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int [] arr= {5, 8, 3, 9, 2};
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
	}

}
