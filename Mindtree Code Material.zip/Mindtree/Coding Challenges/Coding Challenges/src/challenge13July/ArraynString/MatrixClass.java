package challenge13July.ArraynString;

import java.util.Scanner;

public class MatrixClass {

	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter the row size");
		int rowSize = scan.nextInt();
		System.out.println("Enter the column size");
		int colSize = scan.nextInt();
		implement(rowSize, colSize);

	}

	private static void implement(int rowSize, int colSize) {
		int array[][] = new int[rowSize][colSize];
		System.out.println("Enter the elements");
		for (rowSize = 0; rowSize < array.length; rowSize++) {
			for (colSize = 0; colSize < array.length; colSize++) {
				array[rowSize][colSize] = scan.nextInt();
			}
		}
		modify(array, rowSize, colSize);
	}

	

	private static void modify(int[][] array, int rowSize, int colSize) {

		for (int i = 0; i < array.length; i++) {
			int temp = array[i][i];
			array[i][i] = array[0][i];
			array[0][i] = temp;
		}
		print(array);

	}

	private static void print(int[][] array) {
		System.out.println("Output is: ");
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
	}

}
