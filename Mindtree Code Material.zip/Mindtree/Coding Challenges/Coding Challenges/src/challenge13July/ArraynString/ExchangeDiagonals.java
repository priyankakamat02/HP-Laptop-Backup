package challenge13July.ArraynString;

import java.util.Scanner;

public class ExchangeDiagonals {

	private static Scanner scan = new Scanner(System.in);
	
	
	
	public static void main(String[] args) {
		int temp =0;
		System.out.println("Enter the row size");
		int rowSize = scan.nextInt();
		System.out.println("Enter the column size");
		int colSize = scan.nextInt();
		if(rowSize == colSize)
		{
			int array[][] = new int[rowSize][colSize];
			System.out.println("Enter the matrix: ");
			for (rowSize = 0; rowSize < array.length; rowSize++) {
				for (colSize = 0; colSize < array.length; colSize++) {
					array[rowSize][colSize] = scan.nextInt();
				}
			}
			System.out.println("Input matrix: ");
			for (rowSize = 0; rowSize < array.length; rowSize++) {
				for (colSize = 0; colSize < array.length; colSize++) {
					System.out.print(array[rowSize][colSize]+" ");
				}
				System.out.println();
			}
			
			for(int j=0; j<colSize; j++)
			{
				temp = array[j][j];
				array[j][j] = array[j][colSize-1-j];
				array[j][colSize-1-j] = temp;
			}
			System.out.println("Output matrix: ");
			
			for(int i=0; i< rowSize; i++)
			{
				for(int j=0; j< colSize; j++)
				{
					System.out.print(array[i][j]+" ");
				}
				System.out.println();
			}
			
		}
		else 
        {
            System.out.println("Rows not equal to column");
        }
		
	}

}
