package challenge13July.oop;

import java.util.Scanner;

public class CarApplication {

	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter the no. of Cars: ");
		int n= sc.nextInt();
		Car[] car = new Car[n];
		for(int i=0;i<car.length;i++) {
			System.out.println();
			System.out.println("Enter the ID of Car No "+(i+1));
			short id = sc.nextShort();
			System.out.println("Enter the Name of Car No "+(i+1));
			String name= sc.next();
			System.out.println("Enter the Price of Car No "+(i+1));
			float price= sc.nextFloat();
			Car cars = new Car(id, name, price);
			car[i]=cars;
		}
		
		boolean flag = true;
		do {
			mainMenu();
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				displayCars(car);
				break;
			
			case 2:
				Car[] sortByPA = sortCarByPriceAscending(car);
				displayCars(sortByPA);
				break;
				
			case 3:
				Car[] sortByPD = sortCarByPriceDescending(car);
				displayCars(sortByPD);
				break;
				
			case 4:
				Car[] sortByNA = sortCarByNameAscending(car);
				displayCars(sortByNA);
				break;
				
			case 5:
				Car[] sortByND = sortCarByNameDescending(car);
				displayCars(sortByND);
				break;
				
			case 6:
				int pos = searchCar(car);
				if(pos > 0)
				{
					System.out.println("Car found at position: "+pos);
				}
				else
				{
					System.out.println("Car Not Found");
				}
				break;
				
			case 7:
				Car[] update = updatePrice(car);
				displayCars(update);
				break;
			
			case 8:
				System.out.println("Thank You !!");
				flag = false;
				break;
				
			default:
				System.out.println("Invalid Choice !!!");
				break;
			}
			
		} while (flag);
		
	}
	
	public static void mainMenu() {
		System.out.println();
		System.out.println("_*_*_MENU_*_*_");
		System.out.println("(1) Display all the Cars");
		System.out.println("(2) Sort the Cars by price (Ascending)");
		System.out.println("(3) Sort the Cars by price (Descending)");
		System.out.println("(4) Sort the cars by Name (Ascending)");
		System.out.println("(5) Sort the cars by Name (Descending)");
		System.out.println("(6) Binary Search");
		System.out.println("(7) Update Price");
		System.out.println("(8) Exit");
		System.out.println();
	}
	
	public static void displayCars(Car[] car) {
		System.out.println("Car Details:");
		for(int i=0;i<car.length;i++)
		{
			System.out.println("Car No: "+(i+1)+" ID is: "+car[i].getId());
			System.out.println("Car No: "+(i+1)+" Name is: "+car[i].getName());
			System.out.println("Car No: "+(i+1)+" Price is: "+car[i].getPrice());
			System.out.println();
		}
	}
	
	public static Car[] sortCarByNameAscending(Car[] car) {
		for (int i = 0; i < car.length; i++) {
			Car check = car[i];
			int j = i - 1;
			while (j >= 0 && car[j].getName().compareTo(check.getName()) > 0) {
				car[j + 1] = car[j];
				j--;
			}
			car[j + 1] = check;
		}
		return car;
	}
	
	public static Car[] sortCarByNameDescending(Car[] car) {
		for (int i = 0; i < car.length; i++) {
			Car check = car[i];
			int j = i - 1;
			while (j >= 0 && car[j].getName().compareTo(check.getName()) < 0) {
				car[j + 1] = car[j];
				j--;
			}
			car[j + 1] = check;
		}
		return car;
	}
	
	public static Car[] sortCarByPriceAscending(Car[] car) {
		for (int i = 0; i < car.length; i++) {
			Car temp = car[i];
			int j = i - 1;
			while (j >= 0 && (car[j].getPrice()) > temp.getPrice()) {
				car[j + 1] = car[j];
				j--;
			}
			car[j + 1] = temp;
		}
		return car;
	}
	
	public static Car[] sortCarByPriceDescending(Car[] car) {
		for (int i = 0; i < car.length; i++) {
			Car temp = car[i];
			int j = i - 1;
			while (j >= 0 && (car[j].getPrice()) < temp.getPrice()) {
				car[j + 1] = car[j];
				j--;
			}
			car[j + 1] = temp;
		}
		return car;
	}
	
	
	
	
	public static Car[] updatePrice(Car[] car) {
		System.out.println("Enter the Id of car:");
		short id= sc.nextShort();
		System.out.println("Enter the value:");
		float n= sc.nextFloat();
		int flag = 0;
		for(int i=0;i< car.length;i++)
		{
			if(car[i].getId()==id)
			{
				car[i].setPrice(n);
				break;
			}
			else
			{
				flag = 1;
			}
		}
		if(flag == 1)
		{
			System.out.println("Id not found");
		}
		return car;
	}
	
	public static int searchCar(Car[] car) {
		sortCarByNameAscending(car);
		int position = -1;
		System.out.println("Enter the name to search: ");
		String name = sc.next();
		int start = 0, end = car.length, mid = (start + end) / 2;
		while (start <= end) {
			if (name.compareTo(car[mid].getName()) == 0) {
				return position=mid+1;
			}
			if (name.compareTo(car[mid].getName()) > 0) {
				start = mid;
			} else {
				end = mid;
			}
			mid = (start + end) / 2;

		}
		if (start > end) {
			return position;
		}
		return position;
	}

}
