package challenge13July.oop;

public class Car {

	private short id;
	private String name;
	private float price;

	public Car(short id, String name, float price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public short getId() {
		return id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

}
