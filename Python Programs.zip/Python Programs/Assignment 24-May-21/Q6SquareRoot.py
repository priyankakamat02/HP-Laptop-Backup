import math


def square_root(D):
    C=50
    H=30
    Q = math.sqrt(2 * C * D / H)
    return str(math.trunc(Q))


DNum = str(input())
list1 = DNum.split(",")
l1 = []
for i in list1:
    l1.append(square_root(int(i)))

print(",".join(l1))


