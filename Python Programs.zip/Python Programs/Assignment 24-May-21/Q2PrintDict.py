n = int(input())
dict1={}
for i in range(0,n):
    dict1={i: i*i}
    print(dict1)