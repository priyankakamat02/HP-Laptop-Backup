def sorted_words(words):
    arr1 = words.split(', ')
    arr1 = sorted(arr1, key=str)
    return ', '.join(str(i) for i in arr1)

words = str(input())
print(sorted_words( str(input()) ))
