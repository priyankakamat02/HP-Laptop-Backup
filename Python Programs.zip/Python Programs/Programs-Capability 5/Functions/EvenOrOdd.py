def oddOrEven(num):
    if(num%2==0):
        return "even"
    else:
        return "odd"

number=int(input("Enter the number: "))
if number>=0:
    print("The number ",number," is ",oddOrEven(number))
else:
    print("Please enter a non-negative number")