def factorial(num):
    if num==0:
        return 1
    else:
        return num*factorial(num-1)

number=int(input("Enter the number: "))
if number>=0:
    print("The factorial of", number, "is", factorial(number))
else:
    print("Please enter a non-negative number")
