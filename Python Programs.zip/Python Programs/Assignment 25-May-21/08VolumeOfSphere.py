import math
vol = (4/3) * math.pi * 6 * 6 * 6
print("Volume is:", vol)