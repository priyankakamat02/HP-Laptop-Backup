import math
area = math.pi * 50 * 50
print("Area is:", area)