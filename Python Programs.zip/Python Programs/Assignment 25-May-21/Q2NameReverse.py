fname = input("Enter first name: ")
lname = input("Enter last name: ")
print(lname,"",fname)