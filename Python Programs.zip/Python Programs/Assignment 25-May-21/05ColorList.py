color_list = ["Red", "Green", "White", "Black"]
res = [color_list[0],color_list[-1]]
print("The first and last colors in list are:", res)