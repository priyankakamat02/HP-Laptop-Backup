num = int(input("Enter the number: "))
diff = 17-num
if num > 17:
    print(2 * abs(diff))
else:
    print(diff)