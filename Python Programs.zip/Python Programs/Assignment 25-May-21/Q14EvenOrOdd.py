def even_or_odd(n):
    if n%2 == 0:
        print("The number ",n,"is even")
    else:
        print("The number ",n,"is odd")

print(even_or_odd(int(input("Enter the number: "))))