def string_with_copies(str, n):
    result = ""
    for i in range(n):
        result += str
    return result

print(string_with_copies(input("Enter the string: "),int(input("Enter the no of copies: "))))