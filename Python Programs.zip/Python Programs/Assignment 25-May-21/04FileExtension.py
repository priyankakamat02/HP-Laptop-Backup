fileName = input("Enter the file-name:")
fExe = fileName.split(".")
print("Extension is:", fExe[-1])