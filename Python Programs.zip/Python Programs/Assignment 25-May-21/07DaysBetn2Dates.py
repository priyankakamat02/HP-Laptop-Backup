from datetime import date

print("**** FOR FIRST DATE ****")
fdate_year = int(input("Enter the year: "))
fdate_month = int(input("Enter the month: "))
fdate_day = int(input("Enter the day: "))
f_date = date(fdate_year,  fdate_month, fdate_day)

print("\n**** FOR LAST DATE ****")
ldate_year = int(input("Enter the year: "))
ldate_month = int(input("Enter the month: "))
ldate_day = int(input("Enter the day: "))
ldate = date(ldate_year, ldate_month, ldate_day)

delta = ldate - f_date
print(delta.days)

