brand=input("Enter your favourite brand: ")
if(brand=="RC"):
    print("It is Children brand")
elif(brand=="KF"):
    print("It is not that much kick")
elif(brand=="FO"):
    print("Bye one get one free")
else:
    print("Other brands are not recommended")
