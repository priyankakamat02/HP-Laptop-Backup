number=int(input("Enter the number: "))
if number==0:
    print("Zero")
elif number==1:
    print("One")
elif number==2:
    print("Two")
elif number==3:
    print("Three")
elif number==4:
    print("Four")
elif number==5:
    print("Five")
elif number==6:
    print("Six")
elif number==7:
    print("Seven")
elif number==8:
    print("Eight")
elif number==9:
    print("Nine")