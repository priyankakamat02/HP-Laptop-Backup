name= str(input("Enter the name: "))
print("Hello ", name)