num1=int(input("Enter 1st number"))
num2=int(input("Enter 2nd number"))
add=num1+num2
print(add)
