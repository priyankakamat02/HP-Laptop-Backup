number=int(input("Enter the number: "))
if(number%2==0):
    print(number, "is even")
else:
    print(number, "is odd")