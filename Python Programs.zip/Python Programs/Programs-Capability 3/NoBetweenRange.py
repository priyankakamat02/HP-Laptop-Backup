number=int(input("Enter the number: "))
if( number>=1 and number<=100  ):
    print(number, "is between",1," and", 100)
else:
    print(number, "is not between",1," and", 100)
