ch = input("Enter the character: ")
print("ASCII Value is: ", ord(ch))