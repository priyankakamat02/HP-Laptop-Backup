import array

org_array = array.array('i',[2,3,5,4,7,6,8])
print("Original array is: ",org_array)
print("Reversed array is: ")
for i in range(len(org_array)-1,-1,-1):
    print(org_array[i])