from cmath import sqrt
def quadratic_soln(a, b, c):
    det = (b**2) - (4*a*c)
    sqrt_det = sqrt(det)

    if det > 0:
        print("Roots are real and different")
        print("root1 is: ",(-b + sqrt_det)/(2*a))
        print("root2 is: ",(-b - sqrt_det)/(2*a))

    elif det == 0:
        print("Roots are real and same")
        print("Roots: ",-b / (2*a))

    else:
        print("Roots are complex")
        print("root1 is: ",(-b + sqrt_det)/(2*a))
        print("root2 is: ",(-b - sqrt_det)/(2*a))

a = int(input("Enter value of a: "))
b = int(input("Enter value of b: "))
c = int(input("Enter value of c: "))

if a==0:
    print("value of a cannot be zero")
else:
    quadratic_soln(a, b, c)