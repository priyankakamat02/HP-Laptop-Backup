num = int(input("Enter the number: "))

if num >= 0:
    if num > 0:
        print(num," is positive number")
    elif num == 0:
        print(num," is Zero")
else:
    print(num," is negative")