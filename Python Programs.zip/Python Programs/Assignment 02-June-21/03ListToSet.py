lst = [1 ,2 , 4, 5, 3, 4, 2]
print("The list is: ",lst)
print("The set is: ",set(lst))