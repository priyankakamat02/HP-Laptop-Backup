class Student:
    def __init__(self, name, rollNo):
        self.name = name
        self.rollNo = rollNo
        self.lap = self.Laptop()

    def show(self):
        print("Name: ",self.name, "\nRoll No: ",self.rollNo)
        self.lap.show()

    class Laptop:
        def __init__(self):
            self.brand = 'HP'
            self.CPU = 'i5'
            self.RAM = 8

        def show(self):
            print("Brand: ",self.brand, "\nCPU: ",self.CPU,
                  "\nRAM: ",self.RAM)

s1 = Student('Vinayak',2)
s2 = Student('Dhiraj',3)

s1.show()

lap1 = Student.Laptop()


