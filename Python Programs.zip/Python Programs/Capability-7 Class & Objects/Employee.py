class Employee:
    def __init__(self,name,empid):
        self.name=name
        self.empid=empid
    def greet(self):
        print("Welcome to Mindtree {}!!!".format(self.name))

emp1=Employee("Vinayak",101)
print('Name:- ',emp1.name)
print('Employee ID:- ',emp1.empid)
emp1.greet()