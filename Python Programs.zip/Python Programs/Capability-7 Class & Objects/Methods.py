# Instance methods
# Class methods
# Static methods

class Student:
    school = "Milagris"
    def __init__(self,marks1,marks2,marks3):
        self.marks1= marks1
        self.marks2= marks2
        self.marks3= marks3

    def avg(self):
        return (self.marks1 + self.marks2 + self.marks3)/3

    def get_m1(self): # getter
        return self.marks1

    def set_m1(self, value): # setter
        self.marks1 = value

    @classmethod
    def getSchool(cls):
        return cls.school

s1 = Student(34,67,32)
s2 = Student(89,32,12)

print("Average of S1 is", s1.avg())
print(Student.getSchool())