class Computer:

    def __init__(self,CPU,RAM):
        self.CPU= CPU
        self.RAM= RAM

    def config(self):
        print("Config is ", self.CPU, self.RAM)

comp1 = Computer('i5',16)
comp2 = Computer('Ryzen 3',8)

comp1.config()
comp2.config()