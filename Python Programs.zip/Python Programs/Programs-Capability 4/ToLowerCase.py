str1= str(input("Enter the string: "))
ch=""
for i in range(0,len(str1)):
    if ((ord(str1[i])>=65) and (ord(str1[i])<=90)):
        ch+=chr( ord(str1[i])+32 )
    else:
        ch+=chr( ord(str1[i]))
print(ch)

