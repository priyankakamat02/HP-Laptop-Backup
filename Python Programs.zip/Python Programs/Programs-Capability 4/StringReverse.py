str1= str(input("Enter the string: "))
rev=""
count=len(str1)
while count>0:
    rev+=str1[count-1]
    count-=1
print(rev)