str1=str(input("Enter the string: "))
for i in range(0,len(str1)):
    print(str1[i], "at index", str1.index(str1[i]))