str1 = input("Enter the string: ")
freq = {}
for i in str1:
    if i in freq:
        freq[i] += 1
    else:
        freq[i] = 1
print("count of each character in", str1, "is:\n "+str(freq))