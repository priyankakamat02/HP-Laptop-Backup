list=[]
num=int(input("How many numbers: "))
for n in range(num):
    number=int(input())
    list.append(number)
print("Sum of list elements is: ", sum(list))