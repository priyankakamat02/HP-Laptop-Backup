list1 = [1,2,2,3,4,1,5,6,5]
final_list = []
for i in list1:
    if i not in final_list:
        final_list.append(i)
print("List is: ", final_list)
list1 = list(set(list1))
print("(Using set) List is: ", list1)