list1=[4,'abc',3,'xyz',2]
list1.sort(key=mix)