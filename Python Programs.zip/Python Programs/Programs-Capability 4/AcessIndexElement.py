list=[]
num=int(input("How many numbers: "))
for i in range(0,num):
    ele=int(input())
    list.append(ele)
number=int(input("Enter the element: "))
print("The list is: ", list)
print("The index of given number is ", list.index(number))
