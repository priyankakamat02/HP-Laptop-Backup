n=int(input("Enter the no of values: "))
dic = {}
sum=0
for i in range(n):
    keys=input()
    value=int(input())
    dic[keys]=value

x=dic.values()
print(x)
for i1 in dic:
    sum=sum+dic[i]
print("sum is: ",sum)