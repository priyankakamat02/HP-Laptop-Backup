num = str(input("Enter the numbers: "))
lst = num.split(",")
sum=0
product =1
for i in lst:
    sum += int(i)
    product *= int(i)

print("Sum is: ",sum)
print("Product is: ",product)