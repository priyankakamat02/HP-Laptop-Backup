num = str(input("Enter the numbers: "))
lst = num.split(",")
for i in range(0, len(lst)):
    lst[i] = int(lst[i])

print("Maximum is: ",max(lst))
print("Minimum is: ",min(lst))

