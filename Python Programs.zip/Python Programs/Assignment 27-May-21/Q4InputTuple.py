#inp = input("Enter the values: ")
#print(tuple(inp.split(",")))

num = ("One", "Two", "Three")
print(num)

lst = [1,2,3,4,5]
print(lst[-1])