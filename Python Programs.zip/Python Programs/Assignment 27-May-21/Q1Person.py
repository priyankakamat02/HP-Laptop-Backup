class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

p = Person(str(input("Enter name: ")),int(input("Enter age: ")))

print(p.name)
print(p.age)