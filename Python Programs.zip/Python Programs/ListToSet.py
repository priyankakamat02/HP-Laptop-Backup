lst = [1,2,3,2,3,4,5,5]
set1 = set(lst)
print(set1)