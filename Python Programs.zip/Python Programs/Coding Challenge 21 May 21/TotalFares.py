import csv

def cell_read(x,y):
    with open('titanic_data.csv','r') as f:
        reader = csv.reader(f)
        y_cnt = 0
        for n in reader:
            if y_cnt == y:
                cell = n[x]
                return cell
            y_cnt += 1

print(cell_read(4,4))
sum1 = 0
sum2 = 0
for i in range(1,891):
    if cell_read(4,i) == 'male':
        sum1 += float(cell_read(9,i))
    elif cell_read(4,i) == 'female':
        sum2 += float(cell_read(9,i))

print("sum of male is:", sum1)
print("sum of female is:", sum2)
