import csv

cr = csv.reader(open("titanic_data.csv"))
sum = 0
for row in cr:
    _sum = row[1]
    try:
        _sum = float(_sum)
    except ValueError:
        _sum = 0
    sum += _sum
print(sum)






