list = [2 , 3 , 4 , 5]

try:
    print("",list[4])
except IndexError as e:
    print(e)