x = True
y = False
print(f"{x} and {y} is ",x and y)
print(f"{x} or {y} is ",x or y)
print(f" not of {x} is ",not x)
print(f" not of {y} is ",not y)