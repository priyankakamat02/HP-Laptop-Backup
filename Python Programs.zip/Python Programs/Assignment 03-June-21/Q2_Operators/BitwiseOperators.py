x = 10
y = 4
print("x AND y is:",x&y)
print("x OR y is:",x|y)
print("NOT of x is:",~x)
print("NOT of y is:",~y)
print("x XNOR y is:",x ^ y)
print("x << 2 is:",x << 2)
print("x >> 2 is:",x >> 2)
print("y << 2 is:",y << 2)
print("y >> 2 is:",y >> 2)