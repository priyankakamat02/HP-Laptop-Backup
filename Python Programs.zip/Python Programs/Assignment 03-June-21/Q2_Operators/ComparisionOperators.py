x = 10
y = 12
print(f"{x} > {y} is ",x>y)
print(f"{x} < {y} is ",x<y)
print(f"{x} == {y} is ",x==y)
print(f"{x} != {y} is ",x!=y)
print(f"{x} >= {y} is ",x>=y)
print(f"{x} <= {y} is ",x<=y)