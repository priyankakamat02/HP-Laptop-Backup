x = 'Hello World'
print('Hello' in x) #gives TRUE
print('u' not in x) #gives TRUE