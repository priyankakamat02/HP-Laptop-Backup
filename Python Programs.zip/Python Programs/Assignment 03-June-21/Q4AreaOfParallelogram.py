base = float(input("Enter the base: "))
height = float(input("Enter the height: "))
area = base * height
print(f"Area of parallelogram is {area}")