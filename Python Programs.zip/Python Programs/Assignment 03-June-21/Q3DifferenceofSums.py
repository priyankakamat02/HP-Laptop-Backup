def sum_of_difference(n):
    sum_of_squares = 0
    squares_of_sum = 0
    for num in range(1, n+1):
        sum_of_squares += num*num
        squares_of_sum += num

    squares_of_sum = squares_of_sum ** 2
    return squares_of_sum - sum_of_squares

print(sum_of_difference(int(input("Enter the no of terms: "))))