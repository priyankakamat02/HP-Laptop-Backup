def factorial(num):
    fact=1;
    for i in range(1,num+1):
        fact = fact * i
    return fact

num = int(input("Enter the number: "))
if num == 0:
    print("Factorial of ",num,"is",1)
else:
    print("Factorial of",num,"is",factorial(num))
