class Base:
    def __init__(self):
        self._fname = "Vinayak" #protected
        self.__lname = "Kamat" #private

class Derived(Base):
    def __init__(self):
        Base.__init__(self)
        print("calling protected member of base class.")
        print(self._fname)
        print("calling private member of base class.")
        print(self.__lname)

obj1 = Derived()

