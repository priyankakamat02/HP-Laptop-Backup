from abc import ABC, abstractmethod

class parent(ABC):
    @abstractmethod
    def fun1(self):
        pass

    def fun2(self):
        print("In the parent class")

class child(parent):
    def fun1(self):
        print("In the child class")

obj = child()
obj1 = parent()
obj.fun1()
obj.fun2()
obj1.fun1()