class Person:
    def __init__(self,fname,lname):
        self.fname = fname
        self.lname = lname

    def displayname(self):
        print(self.fname, self.lname)

class Employee(Person):
    def __init__(self,fname,lname,hyear):
        super(Employee, self).__init__(fname,lname)
        self.hyear= hyear

    def welcome(self):
        print("Welcome",self.fname,self.lname,"to Mindtree Ltd hired in",self.hyear)

e1 = Employee("Vinayak","Kamat",2019)
e1.welcome()