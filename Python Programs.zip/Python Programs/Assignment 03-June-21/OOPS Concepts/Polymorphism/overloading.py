def multiply(n1, n2):
    print( n1 * n2)

def multiply(n1, n2, n3=3):
    print(n1 * n2 * n3)

multiply(1,2)