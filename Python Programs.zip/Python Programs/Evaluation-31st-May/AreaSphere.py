import math
r =int(input("Enter radius: "))
area = (4/3) * math.pi * r * r * r
print("Area is: ",area)