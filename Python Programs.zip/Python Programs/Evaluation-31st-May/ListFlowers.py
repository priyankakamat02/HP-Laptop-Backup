color_list= ["Red" , "Green", "White", "Black"]
print(color_list[0])
print(color_list[-1])