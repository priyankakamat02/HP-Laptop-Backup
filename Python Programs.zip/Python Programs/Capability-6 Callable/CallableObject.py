def function():
    return 5

let=function
print(callable(let))