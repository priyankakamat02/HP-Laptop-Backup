myList=['Dhiraj' , 'Vinayak', 'Prasad' , 'Rohan']
list_iter=iter(myList)
print(next(list_iter))
print(next(list_iter))
print(next(list_iter))
print(next(list_iter))

#print(list_iter.__next__())
#print(list_iter.__next__())
#print(list_iter.__next__())
#print(list_iter.__next__())