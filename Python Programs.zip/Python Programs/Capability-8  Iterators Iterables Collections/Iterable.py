myList=['Dhiraj' , 'Vinayak', 'Prasad' , 'Rohan']
list_iter=iter(myList)
for i in list_iter:
    print(i)