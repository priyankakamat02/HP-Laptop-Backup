from collections import OrderedDict

dict1 = {}
dict1['name'] = "Vinayak"
dict1['age'] = 23
dict1['nationality'] = "Indian"

print(dict1)

ordered_dict = OrderedDict(dict1)
print(ordered_dict)
