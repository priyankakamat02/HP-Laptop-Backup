from collections import Counter

a=[1,2,3,4,2,3,1,4,5,6]
c= Counter(a)
print(c)