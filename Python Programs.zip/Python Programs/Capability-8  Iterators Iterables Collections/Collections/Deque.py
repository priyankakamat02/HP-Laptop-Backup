from collections import deque

iterable= range(5)
d = deque(iterable)

deque([0,1,2,3,4])
print(d)

d.append(5)
print(d)

d.extend(range(6,10))
print(d)

d.appendleft(6)
print(d)

print(d.count(6))

d.insert(0,0)
print(d)

d.popleft()
print(d)

d.pop()
print(d)

d.remove(6)
print(d)

d.reverse()
print(d)

d.rotate()
print(d)

print(len(d))