from collections import defaultdict

name= "VinayakKamat"
d= defaultdict(int)
for c in name:
    d[c] += 1

print(d)
