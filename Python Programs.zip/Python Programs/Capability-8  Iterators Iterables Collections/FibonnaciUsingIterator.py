class myfibonacci:
    def __init__(self):
        self.prev=0
        self.curr=0

    def __iter__(self):
        self.prev=0
        self.curr=1
        return self

    def __next__(self):
        if self.curr <= 50:
            val=self.curr
            self.curr += self.prev
            self.prev= val
            return val
        else:
            raise StopIteration

myfibbo= myfibonacci()
iter1=iter(myfibbo)
for i in iter1:
    print(i)