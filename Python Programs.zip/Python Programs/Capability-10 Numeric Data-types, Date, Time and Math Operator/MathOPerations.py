import math

print('Value of pi is:', math.pi)
print('cos(pi) is', math.cos(math.pi))