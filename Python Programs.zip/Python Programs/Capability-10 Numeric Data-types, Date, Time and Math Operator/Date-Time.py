from datetime import datetime, timedelta

current_date= datetime.now()
print('Day: '+str(current_date.day))
print('Month: '+str(current_date.month))
print('Year: '+str(current_date.year))

one_day=timedelta(days=1)
yesterday = current_date- one_day
print('Yesterday was: '+ str(yesterday))

birthday= input('When is your birthday (dd/mm/yyyy) ?')
birth_day= datetime.strptime(birthday, '%d/%m/%y')
print('Birthday: ' + str(birth_day))