days_in_feb = 28
print(str(days_in_feb)+ ' days in February')

first_no= input('Enter the 1st no: ')
second_no= input('Enter the 2nd no: ')
print(first_no + second_no)
print(int(first_no) + int(second_no))
print(float(first_no) + float(second_no))